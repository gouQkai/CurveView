//
//  CoordinateView.h
//  TryAgain
//
//  Created by Neil on 16/8/24.
//  Copyright © 2016年 zhk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CoordinateView : UIView

@property (nonatomic , strong) NSMutableArray * dataArr;

@property (nonatomic , strong) CAShapeLayer * myLayer;


-(id)initWithDataArray:(NSMutableArray *)dataArray;

@end
