//
//  ViewController.m
//  TryAgain
//
//  Created by Neil on 16/8/24.
//  Copyright © 2016年 zhk. All rights reserved.
//

#import "ViewController.h"
#import "DataSourceArray.h"
#import "CoordinateView.h"

@interface ViewController ()

@property (nonatomic , strong) NSMutableArray * dataArray;

@end

@implementation ViewController

-(NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    DataSourceArray * data0 = [[DataSourceArray alloc]initWithX:@"1" andY:@"9.3"];
    [self.dataArray addObject:data0];
    DataSourceArray * data1 = [[DataSourceArray alloc]initWithX:@"2" andY:@"7.0"];
    [self.dataArray addObject:data1];
    DataSourceArray * data2 = [[DataSourceArray alloc]initWithX:@"3" andY:@"8.6"];
    [self.dataArray addObject:data2];
    DataSourceArray * data3 = [[DataSourceArray alloc]initWithX:@"4" andY:@"7.8"];
    [self.dataArray addObject:data3];
    DataSourceArray * data4 = [[DataSourceArray alloc]initWithX:@"5" andY:@"4.7"];
    [self.dataArray addObject:data4];
    DataSourceArray * data5 = [[DataSourceArray alloc]initWithX:@"6" andY:@"8.6"];
    [self.dataArray addObject:data5];
    DataSourceArray * data6 = [[DataSourceArray alloc]initWithX:@"7" andY:@"9.0"];
    [self.dataArray addObject:data6];
    DataSourceArray * data7 = [[DataSourceArray alloc]initWithX:@"8" andY:@"6.5"];
    [self.dataArray addObject:data7];
    DataSourceArray * data8 = [[DataSourceArray alloc]initWithX:@"9" andY:@"8.0"];
    [self.dataArray addObject:data8];
//    因为要自己画曲线 必须在初始化时候把数组传进去
    CoordinateView * coordinate = [[CoordinateView alloc]initWithDataArray:self.dataArray];
    coordinate.frame = CGRectMake(20, 50, self.view.frame.size.width - 40, 300);
    [self.view addSubview:coordinate];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
