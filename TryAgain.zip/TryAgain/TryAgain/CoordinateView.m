//
//  CoordinateView.m
//  TryAgain
//
//  Created by Neil on 16/8/24.
//  Copyright © 2016年 zhk. All rights reserved.
//



#import "CoordinateView.h"
#import "DataSourceArray.h"

@implementation CoordinateView


-(id)initWithDataArray:(NSMutableArray *)dataArray
{
    self = [super init];
    if (self) {
        self.dataArr = [NSMutableArray arrayWithArray:dataArray];
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}


-(void)drawRect:(CGRect)rect
{
    CGContextRef currentContext = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(currentContext, 1.0);
    CGContextSetStrokeColorWithColor(currentContext, [UIColor greenColor].CGColor);

    
    NSInteger xBetween = self.bounds.size.width / 12;  // 横坐标为12个月份
    NSInteger yBetween = self.bounds.size.height / 10; // 纵坐标为成绩 满分100
    
    
    // 绘制横坐标 并且标明刻度
    for (int i = 0 ; i < 13; i ++) {  // for循环里面的代码有点扯淡 如果只是绘制xy轴 直接画两条线就好了
        
        CGContextMoveToPoint(currentContext, xBetween * i, self.bounds.size.height - 21);
        CGContextAddLineToPoint(currentContext, (i + 1)* xBetween, self.bounds.size.height - 21);
        CGContextStrokePath(currentContext);
        
        UILabel * xLabel = [[UILabel alloc]init];
        xLabel.text = [NSString stringWithFormat:@"%d",i + 1];
        CGRect bounds = CGRectMake(0, 0, 15, 20);
        xLabel.bounds = bounds;
        xLabel.font = [UIFont systemFontOfSize:13];
        xLabel.center = CGPointMake((i + 1)* xBetween, self.frame.size.height - 1);
        [self addSubview:xLabel];
        
    }
    
    // 绘制纵坐标 并且标明刻度
    for (int i = 0 ; i < 11; i ++) {   // 同上一个for循环
        CGContextMoveToPoint(currentContext, 20, yBetween * i);
        CGContextAddLineToPoint(currentContext, 20, yBetween * (i + 1));
        CGContextStrokePath(currentContext);
        
        UILabel * yLable = [[UILabel alloc]init];
        CGRect bounds = CGRectMake(0, 0, 20, 15);
        yLable.bounds = bounds;
        yLable.font = [UIFont systemFontOfSize:11];
        yLable.center = CGPointMake(0, i * yBetween);
        yLable.text = [NSString stringWithFormat:@"%d",100 - i * 10];
        [self addSubview:yLable];
    }
    
    // 使用UIBezierPth绘制曲线
    UIBezierPath * path = [UIBezierPath bezierPath];
    for (int i = 0; i < self.dataArr.count - 1; i ++) {
        DataSourceArray * modelStart = [[DataSourceArray alloc]init];
        modelStart = self.dataArr[i]; // 这个model类包含了 x轴：月份 y轴：成绩 初始点
        DataSourceArray * modelEnd = [[DataSourceArray alloc]init];
        modelEnd = self.dataArr[i + 1]; // 结束点
        
        //  其实用UIBezierPath就是绘制一个路径 最终渲染在图层上是依靠CALayer 绘制好路径后 赋值给CALayer（或者子类 for example CAShapeLayer）
        //  与CGContextRef其实很相近 方法里的参数基本一样 个人感觉CGContextRef的方法更底层
        CAShapeLayer * curveLayer = [CAShapeLayer layer];
        curveLayer.lineWidth = 1.0f;
        curveLayer.lineCap = kCALineCapRound;
        curveLayer.strokeColor = [UIColor blackColor].CGColor;
        curveLayer.fillColor = [UIColor clearColor].CGColor;
        CGPoint startPoint = CGPointMake([modelStart.xValue integerValue] * xBetween, [modelStart.yValue integerValue] * yBetween);
        CGPoint endPoint = CGPointMake([modelEnd.xValue integerValue] * xBetween, [modelEnd.yValue integerValue] * yBetween);
        [path moveToPoint:startPoint];
        
        
        [path addCurveToPoint:endPoint controlPoint1:CGPointMake((startPoint.x + endPoint.x) / 2, startPoint.y) controlPoint2:CGPointMake((startPoint.x + endPoint.x) / 2, endPoint.y)];
        curveLayer.path = path.CGPath;
        
        CABasicAnimation * animation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
        
        animation.duration = 5;
        animation.fromValue = [NSNumber numberWithInteger:0];
        animation.toValue = [NSNumber numberWithInteger:1];
        [curveLayer addAnimation:animation forKey:@"curveView"];
        
        self.myLayer = curveLayer;
        
        [self.layer addSublayer:curveLayer];
    }
    
}


-(void)dealloc
{
    [self.myLayer removeAnimationForKey:@"curveView"];
}

@end
