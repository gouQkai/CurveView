//
//  DataSourceArray.h
//  TryAgain
//
//  Created by Neil on 16/8/24.
//  Copyright © 2016年 zhk. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface DataSourceArray : NSObject

@property (nonatomic , copy) NSString * xValue;
@property (nonatomic , copy) NSString * yValue;

-(id)initWithX:(NSString *)xValue andY:(NSString *)yValue;
//有时候我们重写父类的init方法时不注意将init后面的第一个字母写成了小写，在这个方法里面又调用父类的初始化方法（self = [super init];）时会报错，错误信息如下：error：Cannot assign to 'self' outside of a method in the init family
// 坑点 之前还记得 长久没用忘记了


@end
